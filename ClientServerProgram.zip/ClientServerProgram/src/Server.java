
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {
        try {
            ServerSocket clienSocket=new ServerSocket(8080);
            System.out.println("Server waiting...");
            Socket serverSocket =clienSocket.accept();
            System.out.println("client connected...");

            BufferedReader socketInput = new BufferedReader(new InputStreamReader(serverSocket.getInputStream()));
            PrintWriter socketOutput = new PrintWriter(new OutputStreamWriter(serverSocket.getOutputStream()), true);
            BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));
            String msg="";
            do{
                System.out.println("Enter massage from clinet" );
                msg = userInput.readLine();
               socketOutput.println(msg);
               System.out.println(msg);
               String srvMsg = socketInput.readLine();
               if(msg.equals("chaw")){
                break;
               }
               System.out.println("Message from server: " + srvMsg);
            }
            while(msg.equals(msg));
            userInput.close();
            socketInput.close();
            socketOutput.close();
            serverSocket.close();
            clienSocket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}